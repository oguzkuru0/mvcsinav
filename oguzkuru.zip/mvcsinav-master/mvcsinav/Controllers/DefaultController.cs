﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvcsinav.Models.entity;

namespace MVCProject.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        mvcsinavEntities1 db = new mvcsinavEntities1();
        [Authorize]
        public ActionResult Index()
        {
            var ogrenciler = db.ogr_tbl.ToList(); 
            return View(ogrenciler); 
        }
        [Authorize]
        public ActionResult YeniOgrenci()
        {
            return View();
        }
        [HttpPost]
        public ActionResult YeniOgrenci(ogr_tbl p)
        {
            db.ogr_tbl.Add(p);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Sil(int id)
        {
            var ogrenci = db.ogr_tbl.Find(id);
            db.ogr_tbl.Remove(ogrenci);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        [Authorize]
        public ActionResult OgrenciGetir(int id)
        {
            var ogrenci = db.ogr_tbl.Find(id);

            return View("OgrenciGetir", ogrenci);
        }
        public ActionResult Guncelle(ogr_tbl p)
        {
            var ogrenci = db.ogr_tbl.Find(p.ogrid);
            ogrenci.ograd = p.ograd;
            ogrenci.ogrsoyad = p.ogrsoyad;
            ogrenci.ogrno = p.ogrno;
            ogrenci.ogrpuan = p.ogrpuan;
            ogrenci.ogrbolumid = p.ogrbolumid;

            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
