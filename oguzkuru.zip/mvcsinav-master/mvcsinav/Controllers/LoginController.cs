﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using mvcsinav.Models.entity;

namespace mvcsinav.Controllers
{
    public class LoginController : Controller
    {
        // GET: Default1
        public ActionResult Index()
        {
            return View();
        }
        mvcsinavEntities1 db = new mvcsinavEntities1();

        // GET: GirisYap
        public ActionResult Giris()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Giris(user_tbl t)
        {
            var bilgiler = db.user_tbl.FirstOrDefault(x => x.username == t.username && x.pass == t.pass);
            if (bilgiler != null)
            {
                FormsAuthentication.SetAuthCookie(bilgiler.username, false);
                return RedirectToAction("Index", "Default");
            }
            else
            {
                return View();
            }
        }
    }
}